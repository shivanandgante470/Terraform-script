# Introduction 
This repository has centralized Terraform Modules for all higher level modules like network, security, hub etc. `modules` directory has all Azure resource level terraform modules, which can be used by higher level modules.

# Contribute
1. clone the repository
```
$ git clone <git repo url>
```
2. create a feature branch like
```
$ git checkout -b feature\add-frontdoor-module-mahesh
```
3. Add changes to feature branch then add and push
```
$ git add .
$ git commit -m "add frontdoor module"
$ git push origin feature\add-frontdoor-module-mahesh
```
4. Create a Pull Request in Azure DevOps for main branch

# Pull Request Constraints
1. PR needs to be approved by atleast 2 approvers.
2. All comments has to be resolved before merge