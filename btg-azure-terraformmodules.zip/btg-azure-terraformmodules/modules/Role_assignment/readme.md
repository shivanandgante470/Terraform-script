
---
layout: page
permalink: \CloudBoost\modules\role-assignment
icon: 
description: Assigns a given Principal (User or Group) to a given Role.
status: Ready for Production
type: S03 Identity
automation: TerraformModule
onlineTemplateReference:https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/role_assignment
onlineServiceDescription: https://docs.microsoft.com/en-us/azure/developer/terraform/
packageId: unknown
buildName: unknown
name: Role Assignment
title: Assigns a given Principal (User or Group) to a given Role.
tags: 
- Role Assignment
---
{%- include template_terraform.html -%}

