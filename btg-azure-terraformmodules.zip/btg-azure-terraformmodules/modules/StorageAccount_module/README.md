---
layout: page
permalink: /Azure/Terraform/Modules/StorageAccount/
title: Azure Storage Account Terraform module
icon: Azure storage Account.png
description: Azure Storage Account Terraform module by the AKS Sogeti community.
status: Ready for Production
type: S08 Datastores
automation: TerraformModule
onlineTemplateReference: 
onlineServiceDescription: 
packageId: unknown
buildName: unknown
name: Azure Storage Account
title: Azure Storage Account Terraform module
tags:
- Azure Kubernetes Service community
- AKS Landing zone by Sogeti community
---

{%- include template_terraform.html -%}

https://github.com/sjones-sot/terraform-azurerm-remote-state-storage