---
layout: page
permalink: /Azure/Terraform/nsg/
icon: Network Security Group_COLOR.png
description: Azure NSG by the AKS Sogeti community.
status: Ready for Production
type: S04 Connectivity
automation: TerraformModule
onlineTemplateReference: 
onlineServiceDescription: 
packageId: unknown
buildName: unknown
name: Azure NSG with Terraform
title: Azure NSG with Terraform
tags:
- Azure Kubernetes Service community
- AKS Landing zone by Sogeti community
- Azure Simple Network Terraform module
---

{%- include template_terraform.html -%}