---
layout: page
permalink: /Azure/Terraform/Modules/ServicePrincipalName/
title: Azure Service Principal Name Terraform module
icon: Azure storage Account.png
description: Create an Azure Service Principal Name by the AKS Sogeti community.
status: Ready for Production
type: S05 Security
automation: TerraformModule
onlineTemplateReference: 
onlineServiceDescription: 
packageId: unknown
buildName: unknown
name: Azure Service Principal name
title: Azure Service Principal name Terraform module
tags:
- Azure Kubernetes Service community
- AKS Landing zone by Sogeti community
---

{%- include template_terraform.html -%}

