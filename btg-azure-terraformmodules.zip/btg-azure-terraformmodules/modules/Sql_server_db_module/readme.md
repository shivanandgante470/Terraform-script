
---
layout: page
permalink: \CloudBoost\modules\sql-server-db
icon: 
description: Allows you to manage an Azure SQL Database
status: Ready for Production
type: S08 Datastores
automation: TerraformModule
onlineTemplateReference:https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/sql_database
onlineServiceDescription: https://docs.microsoft.com/en-us/azure/developer/terraform/
packageId: unknown
buildName: unknown
name: Azure SQL Database 
title: Allows you to manage an Azure SQL Database
tags: 
- SQL Database
---
{%- include template_terraform.html -%}



