
---
layout: page
permalink: \CloudBoost\modules\app-insights
icon: 
description: Manages an Application Insights component.
status: Ready for Production
type: S01 Standards
automation: TerraformModule
onlineTemplateReference:https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/application_insights
onlineServiceDescription: https://docs.microsoft.com/en-us/azure/developer/terraform/
packageId: unknown
buildName: unknown
name: Application Insights
title: Application Insights
tags: 
- Application Insights
---
{%- include template_terraform.html -%}

