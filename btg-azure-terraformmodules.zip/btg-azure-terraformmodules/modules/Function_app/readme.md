
---
layout: page
permalink: \CloudBoost\modules\function-app
icon: 
description: Manages a Function App
status: Ready for Production
type: S07 Compute
automation: TerraformModule
onlineTemplateReference:https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/function_app
onlineServiceDescription: https://docs.microsoft.com/en-us/azure/developer/terraform/
packageId: unknown
buildName: unknown
name: Function App 
title: Manages a Function App
tags: 
- Function App
---
{%- include template_terraform.html -%}

