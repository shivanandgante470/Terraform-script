
---
layout: page
permalink: \CloudBoost\modules\key-vault-access-policy
icon: 
description: Manages a Key Vault Access Policy.
status: Ready for Production
type: S03 Identity
automation: TerraformModule
onlineTemplateReference:https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault_access_policy
onlineServiceDescription: https://docs.microsoft.com/en-us/azure/developer/terraform/
packageId: unknown
buildName: unknown
name: Key Vault Access Policy
title: Key Vault Access Policy
tags: 
-  Key Vault Access Policy
---
{%- include template_terraform.html -%}

