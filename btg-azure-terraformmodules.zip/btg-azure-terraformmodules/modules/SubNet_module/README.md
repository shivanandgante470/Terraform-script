---
layout: page
permalink: /Azure/Terraform/subnet/
icon: Subnet.svg
description: Azure subnet by the AKS Sogeti community.
status: Ready for Production
type: S04 Connectivity
automation: TerraformModule
onlineTemplateReference: 
onlineServiceDescription: 
packageId: unknown
buildName: unknown
name: Azure subnet with Terraform
title: Azure subnet with Terraform
tags:
- Azure Kubernetes Service community
- AKS Landing zone by Sogeti community
- Azure Simple Network Terraform module
---

{%- include template_terraform.html -%}