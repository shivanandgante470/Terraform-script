---
layout: page
permalink: /Azure/Terraform/Modules/ResourceGroup/
title: Azure Resource Group Terraform module
icon: ResourceGroup_COLOR.png
description: Azure Azure Resource Group Terraform module by the AKS Sogeti community.
status: Ready for Production
type: S02 Management
automation: TerraformModule
onlineTemplateReference: 
onlineServiceDescription: 
packageId: unknown
buildName: unknown
name: ResourceGroup
title: Azure Resource Group Terraform module
tags:
- Azure Kubernetes Service community
- AKS Landing zone by Sogeti community
---

{%- include template_terraform.html -%}
