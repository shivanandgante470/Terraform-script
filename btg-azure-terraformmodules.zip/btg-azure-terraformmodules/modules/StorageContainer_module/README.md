---
layout: page
permalink: /Azure/Terraform/Modules/StorageContainer/
title: Azure Storage Container Terraform module
icon: Azure storage Account.png
description: Azure Storage Container Terraform module by the AKS Sogeti community.
status: Ready for Production
type: S08 Datastores
automation: TerraformModule
onlineTemplateReference: 
onlineServiceDescription: 
packageId: unknown
buildName: unknown
name: Azure Storage Container
title: Azure Storage Container Terraform module
tags:
- Azure Kubernetes Service community
- AKS Landing zone by Sogeti community
---

{%- include template_terraform.html -%}

https://github.com/sjones-sot/terraform-azurerm-remote-state-storage