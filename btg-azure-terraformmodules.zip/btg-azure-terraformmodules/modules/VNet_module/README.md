---
layout: page
permalink: /Azure/Terraform/vnet/
icon: Azure Virtual Network_COLOR.png
description: Azure VNet by the AKS Sogeti community.
status: Ready for Production
type: S04 Connectivity
automation: TerraformModule
onlineTemplateReference: 
onlineServiceDescription: 
packageId: unknown
buildName: unknown
name: Azure VNet with Terraform
title: Azure VNet with Terraform
tags:
- Azure Kubernetes Service community
- AKS Landing zone by Sogeti community
- Azure Simple Network Terraform module
---

{%- include template_terraform.html -%}